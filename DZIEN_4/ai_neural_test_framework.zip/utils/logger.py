import csv
import os

def log_metrics(epoch, accuracy, loss, path='results/training_log.csv'):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    file_exists = os.path.isfile(path)
    with open(path, 'a', newline='') as csvfile:
        writer = csv.writer(csvfile)
        if not file_exists:
            writer.writerow(['epoch', 'accuracy', 'loss'])
        writer.writerow([epoch, accuracy, loss])