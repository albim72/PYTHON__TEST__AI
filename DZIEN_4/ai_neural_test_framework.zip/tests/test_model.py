from model.mlp_model import build_mlp
from utils.dataset_generator import load_data

def test_model_accuracy():
    X_train, X_test, y_train, y_test = load_data()
    model = build_mlp(input_dim=X_train.shape[1], output_dim=3)
    model.fit(X_train, y_train, epochs=20, verbose=0)
    loss, acc = model.evaluate(X_test, y_test, verbose=0)
    assert acc > 0.85, f"Accuracy too low: {acc}"
    print(f"Test passed with accuracy: {acc}")