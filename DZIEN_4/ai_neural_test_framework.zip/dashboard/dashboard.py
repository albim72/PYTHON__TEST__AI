import streamlit as st
import pandas as pd

st.title("📊 AI Training Dashboard")

try:
    df = pd.read_csv('results/training_log.csv')
    st.line_chart(df.set_index('epoch'))
except FileNotFoundError:
    st.warning("No training log found. Run training first.")