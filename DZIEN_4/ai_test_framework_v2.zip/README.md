# AI Test Framework (TensorFlow-based)

This is a simple example of a testing framework for a neural network model built using TensorFlow.

## Structure

- `models/simple_cnn.py`: Contains the CNN model definition.
- `tests/test_output_shape.py`: A simple unit test checking model output shape.
- `utils/data_loader.py`: Utility function for loading and preprocessing MNIST dataset.

## How to Run

1. Install requirements:
   ```bash
   pip install tensorflow
   ```

2. Run the test:
   ```bash
   python tests/test_output_shape.py
   ```


## Nowości:
- Testy wieloprzypadkowe z `pytest` (`tests/test_model_shapes.py`)
- Logger predykcji do CSV (`utils/csv_logger.py`)

## Jak uruchomić testy z pytest:
1. Zainstaluj pytest:
   ```
   pip install pytest
   ```

2. Uruchom testy:
   ```
   pytest tests/
   ```

## Jak użyć loggera:
```python
from utils.csv_logger import log_predictions_to_csv
predictions = model.predict(x_test[:10])
log_predictions_to_csv(predictions)
```
Wyniki zostaną zapisane w `logs/predictions.csv`.
