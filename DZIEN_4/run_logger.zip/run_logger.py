from models.simple_cnn import create_model
from utils.data_loader import load_mnist_data
from utils.csv_logger import log_predictions_to_csv

model = create_model()
(x_train, y_train), (x_test, y_test) = load_mnist_data()
predictions = model.predict(x_test[:10])

log_predictions_to_csv(predictions)