import csv
import os

def log_predictions_to_csv(predictions, filepath="logs/predictions.csv"):
    os.makedirs(os.path.dirname(filepath), exist_ok=True)
    with open(filepath, mode="w", newline="") as file:
        writer = csv.writer(file)
        writer.writerow(["Sample Index", "Predicted Class", "Probabilities"])
        for idx, prob in enumerate(predictions):
            predicted_class = int(prob.argmax())
            writer.writerow([idx, predicted_class, list(prob)])
