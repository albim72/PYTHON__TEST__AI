# AI Test Framework (TensorFlow-based)

This is a simple example of a testing framework for a neural network model built using TensorFlow.

## Structure

- `models/simple_cnn.py`: Contains the CNN model definition.
- `tests/test_output_shape.py`: A simple unit test checking model output shape.
- `utils/data_loader.py`: Utility function for loading and preprocessing MNIST dataset.

## How to Run

1. Install requirements:
   ```bash
   pip install tensorflow
   ```

2. Run the test:
   ```bash
   python tests/test_output_shape.py
   ```
   
3. Raport HTML:
   ```bash
   pytest --html=report.html --self-contained-html

   ```

