import numpy as np
import pytest
from models.simple_cnn import create_model

@pytest.mark.parametrize("input_shape,expected_output_shape", [
    ((1, 28, 28, 1), (1, 10)),
    ((2, 28, 28, 1), (2, 10)),
    ((5, 28, 28, 1), (5, 10)),
])
def test_model_shapes(input_shape, expected_output_shape):
    model = create_model()
    dummy_input = np.random.rand(*input_shape).astype(np.float32)
    output = model(dummy_input)
    assert output.shape == expected_output_shape, f"Expected {expected_output_shape}, got {output.shape}"
