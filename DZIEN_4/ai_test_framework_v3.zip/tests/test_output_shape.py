import numpy as np
from models.simple_cnn import create_model

def test_model_output_shape():
    model = create_model()
    dummy_input = np.random.rand(1, 28, 28, 1).astype(np.float32)
    output = model(dummy_input)
    assert output.shape == (1, 10), f"Expected output shape (1, 10), got {output.shape}"

if __name__ == "__main__":
    test_model_output_shape()
    print("Test passed.")
