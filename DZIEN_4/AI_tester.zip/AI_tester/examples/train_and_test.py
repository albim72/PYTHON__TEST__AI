from model.mlp_model import build_mlp
from utils.dataset_generator import load_data
from utils.logger import log_metrics

X_train, X_test, y_train, y_test = load_data()
model = build_mlp(input_dim=X_train.shape[1], output_dim=3)

for epoch in range(1, 31):
    model.fit(X_train, y_train, epochs=1, verbose=0)
    loss, acc = model.evaluate(X_test, y_test, verbose=0)
    print(f"Epoch {epoch} - Accuracy: {acc}, Loss: {loss}")
    log_metrics(epoch, acc, loss)