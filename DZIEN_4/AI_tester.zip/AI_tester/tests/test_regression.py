import pandas as pd

def test_accuracy_improves():
    df = pd.read_csv('results/training_log.csv')
    if len(df) < 2:
        print("Not enough data to evaluate regression.")
        return
    if df['accuracy'].iloc[-1] < df['accuracy'].iloc[0]:
        raise AssertionError("Model accuracy did not improve.")
    print("Accuracy regression test passed.")