# AI Neural Test Framework

Projekt demonstracyjny zawierający sieci neuronowe w TensorFlow oraz narzędzie testujące modele AI.