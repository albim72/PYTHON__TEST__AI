
from models.autoencoder import build_autoencoder
from utils.genetic_optimizer import run_genetic_algorithm

def main():
    print("TODO: Load data, train autoencoder, optimize with GA and clean data.")

if __name__ == "__main__":
    main()
