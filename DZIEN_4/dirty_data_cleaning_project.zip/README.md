
# Dirty Data Cleaning Project

Projekt oparty na AI (sieci neuronowe + algorytm genetyczny) do czyszczenia "brudnych danych" z pliku CSV.

## Struktura projektu
- `data/dirty_data.csv` – uszkodzone dane wejściowe
- `models/autoencoder.py` – model sieci autoenkodera
- `utils/genetic_optimizer.py` – algorytm genetyczny do poprawy wyników
- `notebooks/analysis.ipynb` – analiza danych i wyniki
- `main.py` – główny pipeline czyszczenia

## Wymagania
- Python 3.9+
- TensorFlow
- NumPy
- Pandas
- Scikit-learn

Uruchom:
```bash
python main.py
```
