
import numpy as np
import pandas as pd

def run_genetic_algorithm(df, generations=10, population_size=10):
    best_threshold = 0.01
    np.random.seed(42)

    for gen in range(generations):
        thresholds = np.random.uniform(0.001, 0.1, population_size)
        scores = []
        for t in thresholds:
            score = np.random.rand()  # symulacja jakości
            scores.append((t, score))
        scores.sort(key=lambda x: x[1], reverse=True)
        best_threshold = scores[0][0]
    return best_threshold
