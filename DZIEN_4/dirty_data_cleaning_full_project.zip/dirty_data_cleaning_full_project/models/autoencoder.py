
from tensorflow.keras.models import Model
from tensorflow.keras.layers import Input, Dense

def build_autoencoder(input_dim):
    inp = Input(shape=(input_dim,))
    enc = Dense(4, activation='relu')(inp)
    enc = Dense(2, activation='relu')(enc)
    dec = Dense(4, activation='relu')(enc)
    out = Dense(input_dim, activation='linear')(dec)
    model = Model(inputs=inp, outputs=out)
    model.compile(optimizer='adam', loss='mse')
    return model
