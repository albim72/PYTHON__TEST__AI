
# Dirty Data Cleaning Project: Autoencoder + Genetic Algorithm

Projekt czyszczący brudne dane z pliku CSV przy użyciu:
- Autoenkodera (TensorFlow) do wykrywania anomalii
- Algorytmu genetycznego do doboru progu detekcji błędów

## Uruchomienie
1. Wczytaj notebook `notebooks/cleaning_workflow.ipynb`
2. Upewnij się, że masz zainstalowane: tensorflow, pandas, numpy, scikit-learn
3. Uruchom wszystkie komórki

## Struktura:
- `models/autoencoder.py` – definicja modelu autoenkodera
- `utils/genetic_optimizer.py` – algorytm genetyczny
- `data/dirty_data.csv` – przykładowe dane z błędami
- `notebooks/cleaning_workflow.ipynb` – gotowy pipeline
