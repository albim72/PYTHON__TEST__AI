# Projekt: Zadania Kurs Python

## Struktura katalogów

- `zadanie1.py` – programowanie funkcyjne
- `zadanie2.py` – klasy, property, walidacja
- `zadanie3.py` – obsługa błędów, pliki
- `zadanie4.py` – analiza danych z Pandas/NumPy
- `tests/test_zadanie4.py` – testy jednostkowe w pytest
- `data/dane.txt` – dane do zadania 3
- `data/temperatury.csv` – dane do zadania 4
- `logs/bledy.log` – log błędów z zadania 3

## Jak uruchomić

### 1. Środowisko

Zalecane środowisko:
- Python 3.8+
- Zainstalowane biblioteki:
  ```bash
  pip install pandas numpy pytest
  ```

### 2. Uruchomienie testów (zadanie 4)

Przejdź do katalogu głównego projektu i uruchom:

```bash
pytest tests/test_zadanie4.py
```

### 3. Uruchomienie zadań

```bash
python zadanie1.py
python zadanie2.py
python zadanie3.py
python zadanie4.py
```

Upewnij się, że pliki z danymi (`dane.txt`, `temperatury.csv`) znajdują się w katalogu `data/`.

