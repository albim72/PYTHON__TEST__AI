import pandas as pd
import numpy as np

def load_data(filepath):
    try:
        df = pd.read_csv(filepath, parse_dates=["data"], dayfirst=True)
        df = df.dropna(subset=["data", "temperatura"])
        df["temperatura"] = pd.to_numeric(df["temperatura"], errors="coerce")
        df = df.dropna()
        return df
    except Exception as e:
        print(f"Błąd podczas ładowania danych: {e}")
        return pd.DataFrame()

def analyze_data(df):
    print("Statystyki:")
    print(df["temperatura"].describe())

def compute_trend(df):
    df = df.copy()
    df["tydzien"] = df["data"].dt.isocalendar().week
    weekly_means = df.groupby("tydzien")["temperatura"].mean().diff().dropna()
    return weekly_means

def add_change_column(df):
    df["zmiana"] = df["temperatura"].diff()
    return df

if __name__ == "__main__":
    df = load_data("data/temperatury.csv")
    analyze_data(df)
    trend = compute_trend(df)
    print("\nTrend tygodniowy:")
    print(trend)
    df = add_change_column(df)
    print("\nZ danymi zmian:")
    print(df.head())
