valid_data = []
with open("data/dane.txt", "r", encoding="utf-8") as file, open("logs/bledy.log", "w", encoding="utf-8") as error_file:
    for line in file:
        try:
            name, age = line.strip().split(",")
            age = int(age)
            if not name.isalpha() or age <= 0:
                raise ValueError("Nieprawidłowe dane")
            valid_data.append({"name": name, "age": age})
        except Exception as e:
            error_file.write(line)

if valid_data:
    avg_age = sum(item["age"] for item in valid_data) / len(valid_data)
    print(f"Średni wiek: {avg_age:.2f}")
else:
    print("Brak poprawnych danych.")
