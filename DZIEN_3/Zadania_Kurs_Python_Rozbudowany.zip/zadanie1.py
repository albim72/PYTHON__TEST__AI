from functools import reduce

transactions = [
    {"amount": 100, "type": "income"},
    {"amount": 50, "type": "expense"},
    {"amount": 200, "type": "income"},
    {"amount": 80, "type": "expense"}
]

incomes = list(filter(lambda x: x['type'] == 'income', transactions))
expenses = list(filter(lambda x: x['type'] == 'expense', transactions))

total_income = reduce(lambda acc, x: acc + x['amount'], incomes, 0)
total_expense = reduce(lambda acc, x: acc + x['amount'], expenses, 0)
balance = total_income - total_expense

print(f"Total income: {total_income}")
print(f"Total expense: {total_expense}")
print(f"Balance: {balance}")
