from datetime import datetime

class Book:
    def __init__(self, title, author, year, pages):
        self.title = title
        self.author = author
        self.year = year
        self.pages = pages

    @property
    def pages(self):
        return self._pages

    @pages.setter
    def pages(self, value):
        if value <= 0:
            raise ValueError("Liczba stron musi być większa niż 0")
        self._pages = value

    def description(self):
        return f"{self.title} ({self.year}), autor: {self.author}, liczba stron: {self.pages}"

    @property
    def age(self):
        return datetime.now().year - self.year

books = [
    Book("Python 101", "Jan Kowalski", 2015, 320),
    Book("Zaawansowany Python", "Anna Nowak", 2010, 450),
    Book("Data Science", "Piotr Zieliński", 2020, 500)
]

for book in books:
    print(book.description())
    print(f"Wiek książki: {book.age} lat\n")
