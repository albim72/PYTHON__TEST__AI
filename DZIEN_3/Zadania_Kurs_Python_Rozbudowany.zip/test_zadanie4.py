import pytest
import pandas as pd
from zadanie4 import load_data, compute_trend, add_change_column

def test_load_data():
    df = load_data("temperatury.csv")
    assert not df.empty

def test_compute_trend():
    df = pd.DataFrame({
        "data": pd.date_range(start="2024-01-01", periods=14),
        "temperatura": list(range(14))
    })
    df["data"] = pd.to_datetime(df["data"])
    trend = compute_trend(df)
    assert len(trend) >= 1

def test_add_change_column():
    df = pd.DataFrame({"temperatura": [1.0, 2.0, 1.5]})
    df = add_change_column(df)
    assert "zmiana" in df.columns
