import json
from .utils import normalize_time, is_valid_runner

def process_runners(csv_data: list[dict]) -> list[dict]:
    results = []
    for runner in csv_data:
        if not is_valid_runner(runner):
            continue
        total_time = normalize_time(runner["time"])
        results.append({
            "name": runner["name"],
            "club": runner.get("club", "N/A"),
            "time_sec": total_time
        })
    return sorted(results, key=lambda x: x["time_sec"])

def export_to_json(data: list[dict], filename: str) -> None:
    with open(filename, "w") as f:
        json.dump(data, f, indent=2)
