import re

def normalize_time(timestr: str) -> int:
    parts = list(map(int, timestr.strip().split(":")))
    if len(parts) == 3:
        h, m, s = parts
    elif len(parts) == 2:
        h = 0
        m, s = parts
    else:
        raise ValueError("Invalid time format")
    return h * 3600 + m * 60 + s

def is_valid_runner(runner: dict) -> bool:
    if not runner.get("name") or not runner.get("time"):
        return False
    if not re.match(r'^[0-9]{1,2}:[0-9]{2}(:[0-9]{2})?$', runner["time"]):
        return False
    return True
