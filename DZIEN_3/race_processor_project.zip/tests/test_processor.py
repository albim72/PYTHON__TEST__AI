import pytest
from race_processor.processor import process_runners, export_to_json

def test_process_runners():
    data = [
        {"name": "Ala", "time": "1:20:00", "club": "Tatra"},
        {"name": "Jan", "time": "0:55:00"},
        {"name": "", "time": "1:10:00"},
        {"name": "Invalid", "time": "bad_time"}
    ]
    result = process_runners(data)
    assert len(result) == 2
    assert result[0]["name"] == "Jan"
    assert result[1]["club"] == "Tatra"

def test_export_to_json(tmp_path):
    data = [{"name": "Jan", "club": "X", "time_sec": 321}]
    outfile = tmp_path / "out.json"
    export_to_json(data, outfile)
    assert outfile.exists()
    content = outfile.read_text()
    assert "Jan" in content
