import pytest
from race_processor.utils import normalize_time, is_valid_runner

@pytest.mark.parametrize("input_time,expected", [
    ("1:23:45", 5025),
    ("12:34", 754),
])
def test_normalize_time(input_time, expected):
    assert normalize_time(input_time) == expected

def test_normalize_time_invalid():
    with pytest.raises(ValueError):
        normalize_time("12345")

@pytest.mark.parametrize("runner,expected", [
    ({"name": "Jan", "time": "1:23:45"}, True),
    ({"name": "Anna", "time": "12:34"}, True),
    ({"name": "", "time": "12:34"}, False),
    ({"name": "Marek", "time": ""}, False),
    ({"name": "Ola", "time": "bad_time"}, False)
])
def test_is_valid_runner(runner, expected):
    assert is_valid_runner(runner) == expected
