# Web Testing Examples

This project introduces web testing using:

- Selenium
- Playwright
- Requests
- BeautifulSoup

## Install Dependencies
```bash
pip install -r requirements.txt
playwright install
```

## Run Tests
```bash
pytest selenium_example/test_google.py
pytest playwright_example/test_example_com.py
pytest requests_example/test_api_status.py
pytest beautifulsoup_example/test_parse_html.py
```
