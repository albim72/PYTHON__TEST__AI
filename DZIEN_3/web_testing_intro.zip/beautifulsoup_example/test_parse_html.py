from bs4 import BeautifulSoup

def test_parse_html():
    html = '<html><head><title>Test</title></head><body><p>Hello, World!</p></body></html>'
    soup = BeautifulSoup(html, 'html.parser')
    assert soup.title.string == "Test"
