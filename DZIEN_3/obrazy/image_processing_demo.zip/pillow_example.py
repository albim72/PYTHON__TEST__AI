from PIL import Image

image = Image.open('input.jpg')
gray_image = image.convert('L')
gray_image.save('output_pillow.jpg')
gray_image.show()