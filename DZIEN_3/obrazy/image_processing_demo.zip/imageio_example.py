import imageio.v3 as iio
import numpy as np

image = iio.imread('input.jpg')
gray_image = np.mean(image, axis=2).astype(np.uint8)
iio.imwrite('output_imageio.jpg', gray_image)