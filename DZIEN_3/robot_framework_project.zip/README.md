# Robot Framework Example Project

This is a basic example of a Robot Framework project for use with PyCharm.

## Structure
- `tests/` - contains test cases
- `resources/` - contains shared variables or keywords
- `results/` - default folder for output files

## How to Run
```bash
pip install -r requirements.txt
robot -d results tests/example_test.robot
```
